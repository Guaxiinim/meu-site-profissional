# Checklist de Segurança (essencial antes do go-live)

1. **HTTPS obrigatório**: configure TLS com Let's Encrypt via Certbot (Nginx). Nunca exponha portas HTTP sem redirecionamento para HTTPS.
2. **Variáveis de ambiente seguras**: coloque segredos em `.env` e não faça commit. Use secret manager em produção.
3. **Verificação CAPTCHA**: implemente reCAPTCHA v3 ou hcaptcha e verifique tokens no `routes/contact.js` antes de aceitar leads.
4. **Proteção contra bots**: rate limiting (já incluído), bloqueio de IPs suspeitos, WAF (Cloudflare/WAF do provedor).
5. **Headers de segurança**: `helmet()` habilitado; revise CSP (Content Security Policy) restritiva para suas necessidades.
6. **Sanitização & validação**: já usamos `xss-clean` e `express-mongo-sanitize`, continue validando todos os inputs.
7. **Monitoramento**: configure logs (Winston/LogDNA) e alertas (Sentry, Datadog) para erros e exceções.
8. **Backups**: se for armazenar dados, faça backups criptografados.
9. **Atualizações**: mantenha dependências atualizadas. Use `npm audit` e processos CI para checagens.
10. **Teste de penetração**: antes do go-live, faça scans (OWASP ZAP) e, se possível, um pentest profissional.
