# LumeLaunch — QuickSell-Pro (Versão Personalizada)

Bem-vindo(a)! Este pacote contém uma landing page otimizada para conversão, um backend Node/Express com proteções básicas e instruções para deploy.

**Marca:** LumeLaunch
**Domínio sugerido:** https://lumelaunch.com
**Imagens de demo:** Unsplash (livres para uso não comercial; revise termos para uso comercial)

Siga o `deploy-instructions.md` para subir em um VPS com Docker e Nginx. Antes do go-live, siga `security-checklist.md` para reforçar proteções.
