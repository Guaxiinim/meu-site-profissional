'use strict';
const express = require('express');
const validator = require('validator');
const router = express.Router();

// IMPORTANT: in production, validate against a real CAPTCHA (reCAPTCHA v3, hcaptcha)
router.post('/', async (req,res)=>{
  try{
    const { name, email, message, source } = req.body || {};
    if(!name || !email) return res.status(400).json({ error: 'Nome e email são obrigatórios' });
    if(!validator.isEmail(email)) return res.status(400).json({ error: 'Email inválido' });
    // sanitize input lengths
    if(String(name).length>100||String(message||'').length>1000) return res.status(400).json({ error: 'Campos muito longos' });

    // TODO: verify CAPTCHA token server-side here
    // Example: verify with Google reCAPTCHA -> call verification endpoint

    // In production: store lead securely (DB), send webhook to payment provider, notify via webhook to Slack/Telegram
    // For demo: just respond success

    return res.json({ message: 'Pedido recebido. Checaremos e retornaremos.' });
  }catch(err){
    console.error(err);
    return res.status(500).json({ error: 'Erro interno' });
  }
});

module.exports = router;
