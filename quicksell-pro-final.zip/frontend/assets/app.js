(async ()=>{
  const form = document.getElementById('contactForm');
  const msg = document.getElementById('formMsg');
  if(form){
    form.addEventListener('submit', async (e)=>{
      e.preventDefault();
      msg.textContent='Enviando...';
      const data = new FormData(form);
      const body = {};
      for(const [k,v] of data.entries()) body[k]=v;
      try{
        const res = await fetch('/api/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
        const j = await res.json();
        if(res.ok){ msg.textContent = j.message || 'Enviado com sucesso! Um membro da nossa equipe entrará em contato.'; form.reset(); }
        else { msg.textContent = j.error || 'Erro ao enviar'; }
      }catch(err){ msg.textContent = 'Erro de rede. Tente novamente mais tarde.'; }
    });
  }
  const buy = document.getElementById('buyBtn');
  if(buy) buy.addEventListener('click', ()=>{ window.location.hash='#contact'; document.getElementById('contactForm').scrollIntoView({behavior:'smooth'}); });
  const preview = document.getElementById('previewBtn');
  if(preview) preview.addEventListener('click', ()=>{ alert('Abrindo demo (simulado). Ao subir em um servidor, a demo ficará pública.'); });
})();
