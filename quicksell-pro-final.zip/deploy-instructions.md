# Instruções Rápidas de Deploy

Opção recomendada: VM ou VPS (DigitalOcean, Hetzner, AWS EC2) + Nginx + Docker.

Passos resumidos:
1. Clone repo no servidor.
2. Ajuste `CORS_ORIGIN` e `NODE_ENV` em `docker-compose.yml` ou em variáveis de ambiente.
3. Configure Nginx (use `nginx/site.conf`) e crie `/var/www/certbot` para desafios.
4. Instale Docker & Docker Compose.
5. `docker-compose up -d --build` para subir container.
6. Use Certbot para obter certificado: `certbot --nginx -d yourdomain.com -d www.yourdomain.com`.
7. Configure monitoramento e backups.
